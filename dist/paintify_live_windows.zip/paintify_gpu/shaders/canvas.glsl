

// Canvas setup and the temporal source-difference map -- the small writes that
// do not deserve a stage of their own.
//
// Pass 0 is worker.js `applyUnderpaint` mode 'blur': the coarsest layer's
// Gaussian reference becomes the starting canvas. The first version of this
// renderer blitted the source at 1:1 instead (identical src/dst rects, so
// GL_LINEAR was a straight copy), which left the sharp photograph showing
// through every gap between strokes.

// Units 3 and 4 are already spoken for pipeline-wide (the temporal difference
// map and the brush atlas), so the flow pair continues past them rather than
// reusing numbers that mean something else in every other stage.

                      // 3 = advect the previous canvas along the flow
                      // 5 = clear the dilated changed area to a fresh lay-in

// Where pixel `px` of this frame was in the previous one, in uv. With no flow
// this is just px itself, which is what makes "flow off" and "flow computed
// but nothing moved" the same code path rather than two.
vec2 prevUV(ivec2 px) {
    vec2 uv = (vec2(px) + 0.5) / IMG_SIZE;
    return uv + texture(uFlow, uv).xy / IMG_SIZE;
}

// This frame's lay-in, for pixels whose carried paint is being discarded.
vec3 freshLayIn(ivec2 px) {
    vec3 lay = clamp(texelFetch(uIn, px, 0).rgb, 0.0, 1.0);
    if (styleOn() && ST_GROUND_MODE > 0.5)
        lay = mix(ST_GROUND, styleColor(lay, 0u, false), clamp(ST_UNDER_OPACITY, 0.0, 1.0));
    return lay;
}

// Catmull-Rom resampling of the carried canvas.
//
// Bilinear is not usable here, and the reason is worth stating because it is
// invisible in any single frame. The canvas is warped *again every frame* it
// survives without being repainted, and bilinear interpolation is a low-pass
// filter, so the blur compounds: measured over eleven frames of a pan with no
// repainting, bilinear cost 89% of the image's sharpness (variance of the
// Laplacian 652 -> 75). The painting dissolved while every frame-to-frame
// stability number looked excellent.
//
// Catmull-Rom has negative lobes that restore what a resample takes out, which
// is why temporal anti-aliasing uses it for exactly this job. It does not make
// the warp lossless, only slow enough to lose that the ordinary repaint
// threshold refreshes paint faster than the warp degrades it.
float crWeight(float t, int i) {
    float t2 = t * t, t3 = t2 * t;
    if (i == 0) return -0.5 * t3 +       t2 - 0.5 * t;
    if (i == 1) return  1.5 * t3 - 2.5 * t2            + 1.0;
    if (i == 2) return -1.5 * t3 + 2.0 * t2 + 0.5 * t;
    return              0.5 * t3 - 0.5 * t2;
}

vec3 sampleCatmullRom(vec2 uv) {
    vec2 size = IMG_SIZE;
    vec2 xy = uv * size - 0.5;
    vec2 base = floor(xy);
    vec2 f = xy - base;

    vec3 acc = vec3(0.0);
    float wsum = 0.0;
    for (int j = 0; j < 4; ++j) {
        float wy = crWeight(f.y, j);
        for (int i = 0; i < 4; ++i) {
            float w = crWeight(f.x, i) * wy;
            ivec2 q = clamp(ivec2(base) + ivec2(i - 1, j - 1),
                            ivec2(0), ivec2(size) - 1);
            acc += texelFetch(uPrevCanvas, q, 0).rgb * w;
            wsum += w;
        }
    }
    // The weights sum to 1 analytically; normalising covers the clamped edge
    // taps, where the same texel is counted more than once.
    return acc / max(wsum, 1e-5);
}

void main() {
    ivec2 px = ivec2(gl_GlobalInvocationID.xy);
    ivec2 size = ivec2(IMG_SIZE);
    if (px.x >= size.x || px.y >= size.y) return;

    if (uPass == 0) {
        imageStore(uCanvas, px, vec4(clamp(texelFetch(uIn, px, 0).rgb, 0.0, 1.0), 1.0));
    } else if (uPass == 4) {
        // brushkit ground: a toned, hand-brushed ground with a thin lay-in of
        // the blurred motif over it (painter.underpaint). Thin is the point --
        // at underOpacity < 1 the ground keeps glowing through every gap.
        vec2 p = vec2(px);
        float mottle = 0.035 * fbm(p / 90.0, 4, 911u);
        vec3 ground = clamp(ST_GROUND * (1.0 + mottle), 0.0, 1.0);
        vec3 lay = styleColor(clamp(texelFetch(uIn, px, 0).rgb, 0.0, 1.0), 0u, false);
        lay = clamp(lay * (1.0 + 0.04 * fbm(p / 40.0, 3, 913u)), 0.0, 1.0);
        imageStore(uCanvas, px, vec4(mix(ground, lay, clamp(ST_UNDER_OPACITY, 0.0, 1.0)), 1.0));
    } else if (uPass == 1) {
        imageStore(uCanvas, px, vec4(clamp(uFill, 0.0, 1.0), 1.0));
    } else if (uPass == 3) {
        // Advect the previous frame's paint along the flow. This is the whole
        // point of computing the flow: on a pan the painting then travels with
        // the subject instead of staying pinned to the pixel grid, and the
        // difference test below finds almost nothing left to repaint.
        //
        // What it does not do is re-orient a stroke to the new flow field, or
        // move strokes as objects -- the carried state here is a canvas, not a
        // stroke list, so this advects the image of the painting. See
        // docs/flow.md for what that costs.
        vec2 uvp = prevUV(px);

        // brushkit: content that has just entered the frame has no previous
        // paint -- sampling past the edge would smear the border column across
        // it. Give it a fresh lay-in instead (uIn holds this frame's coarsest
        // blur), and pass 2 marks it as changed so it gets strokes.
        if (styleOn() && (any(lessThan(uvp, vec2(0.0))) || any(greaterThan(uvp, vec2(1.0))))) {
            vec3 lay = clamp(texelFetch(uIn, px, 0).rgb, 0.0, 1.0);
            if (ST_GROUND_MODE > 0.5)
                lay = mix(ST_GROUND, styleColor(lay, 0u, false), clamp(ST_UNDER_OPACITY, 0.0, 1.0));
            imageStore(uCanvas, px, vec4(lay, 1.0));
            return;
        }

        // A pixel that did not move must not be resampled at all. Any filter,
        // Catmull-Rom included, loses a little each time it is applied, and
        // over a long shot that loss is cumulative -- so on footage where the
        // camera is still and only part of the frame moves, an unconditional
        // warp would slowly dissolve a background that never needed touching.
        // Snapping sub-hundredth-pixel flow to an exact texel copy makes the
        // still parts of a shot exactly lossless, which is the case most
        // footage spends most of its time in.
        vec2 dpx = (uvp - (vec2(px) + 0.5) / IMG_SIZE) * IMG_SIZE;
        if (dot(dpx, dpx) < 1e-4) {
            imageStore(uCanvas, px, vec4(texelFetch(uPrevCanvas, px, 0).rgb, 1.0));
            return;
        }

        // The clamp is not cosmetic: Catmull-Rom's negative lobes overshoot at
        // a hard stroke edge, and an unclamped negative or >1 value here is
        // carried into the next frame's warp and amplified.
        imageStore(uCanvas, px, vec4(clamp(sampleCatmullRom(uvp),
                                           0.0, 1.0), 1.0));
    } else if (uPass == 5) {
        // Clear around motion: uMask is the source difference grown by the
        // stroke reach. Carried paint there is replaced by this frame's
        // lay-in, so strokes of whatever moved away cannot linger as a trail.
        if (texelFetch(uMask, px, 0).r >= FRAME_DIFF)
            imageStore(uCanvas, px, vec4(freshLayIn(px), 1.0));
    } else {
        // Mean absolute channel difference, the quantity worker.js thresholds
        // against frameDiffThreshold (which is on a 0..255 scale, so scale up).
        //
        // With flow on, the comparison is motion-compensated: the question
        // becomes "did this piece of the subject change?" rather than "did the
        // colour at this pixel change?". Under a pure translation the first
        // answer is no everywhere and the second is yes everywhere, which is
        // exactly why a pan rebuilt the whole painting every frame.
        vec3 prev = (uUseFlow != 0) ? texture(uPrevSrc, prevUV(px)).rgb
                                    : texelFetch(uPrevSrc, px, 0).rgb;
        vec3 d = abs(texelFetch(uSrc, px, 0).rgb - prev);
        float diff = dot(d, vec3(1.0)) / 3.0 * 255.0;
        // brushkit: newly exposed content always counts as changed.
        if (styleOn() && uUseFlow != 0) {
            vec2 uvp = prevUV(px);
            if (any(lessThan(uvp, vec2(0.0))) || any(greaterThan(uvp, vec2(1.0)))) diff = 255.0;
        }
        // Anti-smear. Warped paint is what makes motion look like spilled
        // paint, so where the subject moves faster than the limit the carried
        // paint is thrown away and the pixel is painted fresh this frame.
        if (uFreshPaint > 0.0) {
            bool fresh;
            if (uUseFlow != 0) {
                float motion = length(texture(uFlow, (vec2(px) + 0.5) / IMG_SIZE).xy);
                fresh = motion > mix(6.0, 0.25, uFreshPaint);
            } else {
                // No flow: tighten the source-change test instead.
                fresh = diff > FRAME_DIFF * mix(4.0, 0.5, uFreshPaint);
            }
            if (fresh) {
                diff = 255.0;
                imageStore(uCanvas, px, vec4(freshLayIn(px), 1.0));
            }
        }
        imageStore(uDiff, px, vec4(diff, 0.0, 0.0, 0.0));
    }
}
